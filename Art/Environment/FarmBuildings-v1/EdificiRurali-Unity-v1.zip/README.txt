ROG ZOMBIE - EDIFICI RURALI v1
Tre modelli scenografici: Fienile_01_Annesso, Rimessa_02_Rurale, Casa_03_Abbandonata.
Stile comune: fattoria consumata, legno sbiadito e lamiera arrugginita.
Reference principali fornite dall'utente:
b86ea17e16fe48dfb6de2dca8e820895.jpg - tetto spezzato e annesso del fienile.
ebdceabc983962147d9a73adfe4d85a1.jpg - volume compatto della rimessa.
86af7808943207a999b96a2061c42abb.jpg - guida prioritaria per palette e invecchiamento.
Non sono inclusi campi, animali o recinzioni della reference.

MODELLI / DIMENSIONI X,Y,Z IN METRI
Fienile_01_Annesso: 486 triangoli; 9.020 x 7.555 x 8.620.
Rimessa_02_Rurale: 292 triangoli; 5.067 x 4.905 x 6.620.
Casa_03_Abbandonata: 358 triangoli; 5.866 x 5.440 x 7.620.
Dimensioni artistiche provvisorie, modificabili dalla scala in Unity.
Asse Y verticale, pivot al suolo sotto il corpo principale.
Geometrie esterne con porte e finestre chiuse; nessun interno navigabile.
Nessun collider, animazione, distruzione o gameplay.
Nessun inserimento automatico nelle scene.

OTTIMIZZAZIONE
OBJ triangolati con UV planari, normali esplicite, Read/Write disabilitato.
Due materiali condivisi: FarmAtlas URP/Lit opaco e Dark per vetri scuri.
Un atlas importato a massimo 512 px, Point, mipmaps, no compressione.
Coperture con spessore, UV orientate lungo le falde.
Materiali opachi e instancing abilitato. Nessuna texture normale o trasparenza.

UNITY
Asset gia' in Assets/Environment/FarmBuildingsLowPoly.
Attendere importazione, poi ROG ZOMBIE > Art > Crea prefab edifici rurali.
Il menu crea i tre prefab nella stessa cartella senza sovrascrivere quelli esistenti.
Trascinare i prefab nella scena. E' possibile trascinare direttamente anche gli OBJ.
Per trasferirli a un progetto URP copiare Assets dal pacchetto ZIP.
Controllare l'aspetto con la camera top-down del proprio progetto.

VERIFICA
Indici, UV, normali, triangoli e base dei modelli verificati.
Utility C# compilata con riferimenti Unity.
Edifici_preview.png mostra render software degli OBJ reali a 48 e 90 gradi.
Non e' uno screenshot Unity; importazione e resa nell'Editor da confermare.
Ogni modello e' adattato al suo riquadro nell'anteprima, non in scala reciproca.
Nessun commit o build. Nessun package, impostazione, GDD o scena modificati.

TEXTURE
Generata tramite image_gen incorporato, nessuna modifica raster successiva.
Originale conservato: exec-a5d3c9b2-642c-46b0-b363-c9056547a823.png.
Prompt:
Single square opaque game texture atlas, four EXACT equal quadrants at 50% width and height. Coherent gritty rustic abandoned farm aesthetic, retro 32-bit pixel art, chunky deliberate pixels and limited muted earth palette, NOT photorealistic. TOP LEFT: weathered desaturated reddish brown vertical timber planks with peeling paint, gray exposed grain, board seams. TOP RIGHT: very worn pale gray beige wooden horizontal clapboard siding with scratches and dark grain. BOTTOM LEFT: old gray corrugated sheet metal with large irregular patches of burnt sienna rust, narrow parallel vertical corrugations, flat face on, no holes. BOTTOM RIGHT: rough gray brown stone foundation masonry with large simple stones and mortar seams. Each quadrant fills its exact square with no margin. Flat albedo even lighting, no perspective, no objects, no labels, no lettering, no borders, no baked cast shadows. All four swatches visually belong to the same aged rural buildings in a top-down zombie game. Effective pixel detail 128x128 per quadrant; keep clear large material shapes, avoid fine noise.
